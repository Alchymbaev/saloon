package kg.mega.saloon.enums;

public enum WorkTypeEnum {
    NAILS,
    HAIR,
    LASHES,
    MAKEUP,
    EYEBROW;
}
