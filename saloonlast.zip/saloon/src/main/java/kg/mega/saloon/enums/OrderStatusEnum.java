package kg.mega.saloon.enums;

public enum OrderStatusEnum {
    CONFIRM,
    CANCELED,
    SUSPEND;

}
