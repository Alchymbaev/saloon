package kg.mega.saloon.service;

import kg.mega.saloon.models.dto.SaloonDto;

public interface SaloonService extends BaseService<SaloonDto>{
}
