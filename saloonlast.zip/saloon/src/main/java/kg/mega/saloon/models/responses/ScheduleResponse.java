package kg.mega.saloon.models.responses;

import kg.mega.saloon.enums.WorkDayEnum;

public class ScheduleResponse {
    WorkDayEnum workDayEnum;
    String schedule;
}
