package kg.mega.saloon.dao;

import kg.mega.saloon.models.entities.Saloon;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaloonRep extends JpaRepository<Saloon,Long> {

}
